/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgtry;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Bus {
    private String Bus_ID;
    private String Bus_lic;

    public Bus() {
    }

    public Bus(String Bus_ID, String Bus_lic) {
        this.Bus_ID = Bus_ID;
        this.Bus_lic = Bus_lic;
    }

   

    public String getBus_ID() {
        return Bus_ID;
    }

    public void setBus_ID(String Bus_ID) {
        this.Bus_ID = Bus_ID;
    }

    public String getBus_lic() {
        return Bus_lic;
    }

    public void setBus_lic(String Bus_lic) {
        this.Bus_lic = Bus_lic;
    }

    
    
}
